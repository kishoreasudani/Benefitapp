//import libraries
import React, { Component } from 'react';
import {
    StyleSheet,
    View,
    Alert,
    Image,
    Platform,
    Text,
    ImageBackground,
    TouchableOpacity,
    StatusBar,
    TextInput,
    Icon
} from 'react-native';
import { Body, Header, Left, Right } from "native-base";
import { connect } from "react-redux";
import { ActionCreators } from "../actions/index";
import { Images } from "../assets/Images/index";
import * as Utils from "../lib/utils";
import { GlobalStyle } from "../assets/styles/GlobalStyle";
import { ScrollView } from 'react-native-gesture-handler';
import LinearGradient from 'react-native-linear-gradient';

// create a component
class WeekGraphScreen extends Component {
    _isMount = false;
    static navigationOptions = {
        header: null
    };

    constructor (props) {
        super(props);
        this.state = {
            username: '',
            password: ''
        }
    }

    componentDidMount() {
        this._isMount = true;
    }

    componentWillUnmount() {
        this._isMount = false;
    }

    render() {
        const data = [50, 10, 40, 95, -5, -24, 85, 91, 35, 53, -53, 24, 50, -20, -80]

        return (
            <View style={ [GlobalStyle.container, localStyle.container] }>
                <Header
                    style={ GlobalStyle.header }
                    androidStatusBarColor="#333"
                    iosBarStyle="light-content"
                >
                    <Left style={ { flex: 1 } }>
                        <TouchableOpacity onPress={ () => this.props.navigation.goBack() }>
                            <Image source={ Images.backArrow } style={ {
                                marginRight: Utils.moderateScale(15, 0.5),
                                width: Utils.moderateScale(18),
                                height: Utils.moderateScale(14)
                            } } resizeMode="contain" resizeMethod="resize" />
                        </TouchableOpacity>
                    </Left>

                    <Body style={ GlobalStyle.headerBody }>
                        <Text style={ GlobalStyle.headerTitle }>Week Graph </Text>
                    </Body>
                    <Right>

                    </Right>
                </Header>
                <ScrollView>

                    <View style={ localStyle.innerContainer }>
                        <View style={ [GlobalStyle.card, localStyle.card, { flexDirection: 'row', justifyContent: 'space-between' }] }>

                            <View
                                style={ {
                                    flex: 1,
                                    flexDirection: "row",
                                    // paddingTop: 80,
                                    fontSize: 15,
                                    justifyContent: 'space-evenly'
                                } }
                            >
                                <View style={ localStyle.innerContainer }>
                                    <Text style={ { color: '#fff', fontWeight: '400', fontSize: Utils.moderateVerticalScale(15) } }>Highest Record </Text>
                                    <Text style={ { color: '#555555', fontWeight: '400', fontSize: Utils.moderateVerticalScale(15) } }>28 July,2019 Sun </Text>

                                </View>


                                <View style={ localStyle.innerContainer }>
                                    <Text style={ { color: '#fff', fontSize: Utils.moderateVerticalScale(18) } }>2157 steps </Text>
                                    <Text style={ { color: '#555555', fontSize: Utils.moderateVerticalScale(18) } }>13km </Text>
                                </View>
                            </View>
                        </View>

                    </View>

                    <View style={ localStyle.innerContainer }>
                        <View style={ [GlobalStyle.card, localStyle.card, { flexDirection: 'row', justifyContent: 'space-between' }] }>
                            <View
                                style={ {
                                    flex: 1,
                                    flexDirection: "row",
                                    // paddingTop: 10,
                                    fontSize: 15,
                                } }
                            >

                                <Text style={ {
                                    marginLeft: 25,
                                    color: "#555555"
                                } }>
                                    Steps
                                </Text>

                                <Text style={ {
                                    marginLeft: 80,
                                    color: "#555555"
                                } }>
                                    XCAL
                                </Text>

                                <Text style={ {
                                    marginLeft: 75,
                                    color: "#555555"
                                } }>
                                    Distance
                                </Text>
                            </View>


                        </View>
                    </View>

                    {/* <View style={ { height: 200, padding: 20 } }>
                                <LineChart
                                    style={ { flex: 1 } }
                                    data={ data }
                                    gridMin={ 0 }
                                    contentInset={ { top: 10, bottom: 10 } }
                                    svg={ { stroke: 'rgb(134, 65, 244)' } }
                                >
                                    <Grid />
                                </LineChart>
                                <XAxis
                                    style={ { marginHorizontal: -10 } }
                                    data={ data }
                                    formatLabel={ (value, index) => index }
                                    contentInset={ { left: 10, right: 10 } }
                                    svg={ { fontSize: 10, fill: 'black' } }
                                />
                            </View>  */}

                    <View style={ localStyle.innerContainer }>
                        <View style={ [GlobalStyle.card, localStyle.card, { flexDirection: 'row', justifyContent: 'space-between' }] }>

                            <View style={ { flexDirection: 'row', borderBottomWidth: 1, padding: 10, borderBottomColor: '#3C3C3C', width: '90%', justifyContent: 'flex-start', marginHorizontal: Utils.moderateScale(10) } }>

                                <Image source={ Images.bar_chart }
                                    style={ {
                                        //     width: Utils.moderateVerticalScale(100),
                                        //     height: Utils.moderateVerticalScale(100),
                                        //     borderRadius: Utils.moderateVerticalScale(100 / 2),
                                        alignItems: "center",
                                        //     zIndex: 10,
                                        //     marginTop: Utils.moderateVerticalScale(-40)
                                    } }
                                />
                            </View>
                        </View>
                    </View>

                    <View style={ localStyle.innerContainer }>
                        <View style={ [GlobalStyle.card, localStyle.card, { flexDirection: 'row', justifyContent: 'space-between' }] }>

                            <View
                                style={ {
                                    flex: 1,
                                    flexDirection: "row",
                                    // paddingTop: 80,
                                    fontSize: 15,
                                    justifyContent: 'space-between'
                                } }
                            >
                                <View style={ localStyle.innerContainer }>
                                    <Text style={ { color: '#555555', fontWeight: '400', fontSize: Utils.moderateVerticalScale(10) } }>Total Steps</Text>
                                    <Text style={ { color: '#fff', fontSize: Utils.moderateVerticalScale(10) } }>60,057 Steps </Text>
                                </View>

                            </View>

                            <View
                                style={ {
                                    flex: 1,
                                    flexDirection: "row",
                                    // paddingTop: 80,
                                    fontSize: 15,
                                    // justifyContent: 'space-between'
                                } }
                            >

                                <View style={ localStyle.innerContainer }></View>
                                <Text style={ { color: '#555555', marginHorizontal: Utils.moderateScale(4) } }>|</Text>
                            </View>

                            <View
                                style={ {
                                    flex: 1,
                                    flexDirection: "row",
                                    // paddingTop: 80,
                                    fontSize: 15,
                                    justifyContent: 'space-between'

                                } }
                            >
                                <View style={ localStyle.innerContainer }>
                                    <Text style={ { color: '#555555', fontWeight: '400', fontSize: Utils.moderateVerticalScale(10) } }>Avg Steps</Text>
                                    <Text style={ { color: '#fff', fontSize: Utils.moderateVerticalScale(10) } }>3,533 Steps </Text>
                                </View>
                            </View>
                        </View>
                    </View>

                </ScrollView>
            </View>
        );
    }
}

// define your localStyle
const localStyle = StyleSheet.create({
    container: {
        backgroundColor: '#161616',
        flex: 1,
        justifyContent: 'center',
        alignContent: 'center',
    },
    innerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignContent: 'center',
        width: '100%',
        paddingVertical: Utils.moderateVerticalScale(10)
    },

    card: {
        margin: Utils.moderateScale(15),
        paddingVertical: Utils.moderateVerticalScale(10),
        backgroundColor: '#272727',
        flex: 1,
        justifyContent: 'center',
        alignContent: 'center'
    },
    MainContainer: {
        flex: 1,
        paddingTop: Utils.moderateScale(20),
        alignItems: "center",
        marginTop: Utils.moderateVerticalScale(50),
        justifyContent: "center"
    },
    input: {
        marginTop: Utils.moderateVerticalScale(5),
        marginLeft: Utils.moderateScale(10),
        alignSelf: 'stretch',
        padding: Utils.moderateScale(3),
        margin: Utils.moderateScale(2)

    },
    formGroup: {
        flex: 1,
        flexDirection: "row"
    },
    textContainer: {
        alignItems: 'center',
        color: '#555555',
        marginTop: Utils.moderateVerticalScale(2),
        marginLeft: Utils.moderateScale(10),
        alignSelf: 'stretch',
        padding: Utils.moderateScale(3),
        margin: Utils.moderateScale(2)
    },
    formLabel: {
        alignItems: 'center',
        color: '#555555',
        marginTop: Utils.moderateVerticalScale(2),
        marginLeft: Utils.moderateScale(10),
        alignSelf: 'stretch',
        padding: Utils.moderateScale(2),
        margin: Utils.moderateScale(2)

    },
    buttonContainer1: {
        marginVertical: Utils.moderateVerticalScale(30),
        height: Utils.moderateVerticalScale(60),
        width: Utils.moderateVerticalScale(300),
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: Utils.moderateVerticalScale(50),
        marginLeft: Utils.moderateScale(35)
    },
    circle: {
        width: Utils.moderateVerticalScale(35),
        height: Utils.moderateVerticalScale(35),
        marginVertical: Utils.moderateVerticalScale(20),
        borderRadius: Utils.moderateScale(18),
        backgroundColor: '#555555',
        justifyContent: 'center',
        alignItems: 'center',
    }
});

const mapStateToProps = state => {
    return {};
};

const mapDispatchToProps = dispatch => {
    return {};
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(WeekGraphScreen);    