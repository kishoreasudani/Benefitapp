//import libraries
import React, { Component } from 'react';
import {
    StyleSheet,
    View,
    Alert,
    Image,
    Text,
    ImageBackground,
    TouchableOpacity,
    StatusBar,
    TextInput,
    Icon,

} from 'react-native';
import { connect } from "react-redux";
import { ActionCreators } from "../actions/index";
import * as Utils from "../lib/utils";
import { ScrollView } from 'react-native-gesture-handler';
import LinearGradient from 'react-native-linear-gradient';
import { Avatar, Badge, withBadge } from "react-native-elements";
import { GlobalStyle } from "../assets/styles/GlobalStyle";
import { Images } from "../assets/Images/index";

// create a component
class HomeScreen extends Component {
    _isMount = false;
    static navigationOptions = {
        header: null
    };

    constructor (props) {
        super(props);
        this.state = {
            username: '',
            password: ''
        }
    }

    componentDidMount() {
        this._isMount = true;
    }

    componentWillUnmount() {
        this._isMount = false;
    }

    render() {
        return (
            <ImageBackground source={ Images.background } style={ GlobalStyle.imageBackground }>
                <StatusBar backgroundColor="transparent" barStyle="light-content" />
                <ScrollView>
                    <View
                        style={ {
                            flex: 1,
                            flexDirection: "row",
                            paddingTop: 80,
                            fontSize: 15
                        } }
                    >

                        <Text style={ {
                            marginLeft: 30,
                            color: "#555555"
                        } }>
                            Today
                    </Text>
                        <Text style={ {
                            marginLeft: 95,
                            color: "#555555"
                        } }>
                            Week
                    </Text>
                        <Text style={ {
                            marginLeft: 100,
                            color: "#555555"
                        } }>
                            Month
                    </Text>

                        {/* <View>
                            
                            var option = {  
                                series: [{
                                type: 'liquidFill',
                                data: [0.6, 0.5, 0.4, 0.3] 
                             }]
                            }; 
                    
                        </View>  */}
                    </View>

                    <View style={ { flexDirection: 'row', justifyContent: 'space-between' } }>
                        <Image source={ Images.liquid_fill }
                            style={ {
                                width: Utils.moderateVerticalScale(200),
                                height: Utils.moderateVerticalScale(200),
                                borderRadius: Utils.moderateVerticalScale(200 / 2),
                                alignItems: "center",
                                zIndex: 10,
                                marginTop: Utils.moderateVerticalScale(40)
                            } }
                        />
                    </View>

                    <View style={ {
                        flexDirection: 'row',

                    } }>
                        <View style={ localStyle.innerContainer }>
                            <View style={ [GlobalStyle.card, localStyle.card] }>
                                <TouchableOpacity>

                                    <Image source={ Images.distance }
                                        style={ {
                                            width: 40,
                                            height: 40,
                                            borderRadius: 40 / 2,
                                            alignItems: "center",
                                            //marginTop: -55,
                                            //marginLeft: Utils.moderateScale(15, 0.5)

                                        } }
                                    />
                                </TouchableOpacity>
                                <View
                                    style={ {
                                        flex: 1,
                                        flexDirection: "row",
                                        justifyContent: 'center',
                                        alignContent: 'center'
                                    } }
                                >
                                    <View
                                        style={ {
                                            height: 120,
                                            width: "45%",
                                            marginBottom: 25,
                                            marginLeft: 10,
                                            fontSize: 18,
                                            padding: 7
                                        } }
                                    >
                                        <Text style={ {
                                            fontSize: 15, color: "#fff", justifyContent: 'center', alignContent: 'center',
                                        } }>7.5Km</Text>
                                        <Text style={ { fontSize: 10, color: "#fff", marginTop: Utils.moderateScale(-2) } }>Distance</Text>

                                    </View>
                                </View>
                            </View>
                        </View>

                        <View style={ localStyle.innerContainer }>
                            <View style={ [GlobalStyle.card, localStyle.card] }>
                                <TouchableOpacity>

                                    <Image source={ Images.calories }
                                        style={ {
                                            width: 40,
                                            height: 40,
                                            borderRadius: 40 / 2,
                                            alignItems: "center",
                                            //marginTop: -55,
                                            //marginLeft: Utils.moderateScale(15, 0.5)

                                        } }
                                    />
                                </TouchableOpacity>
                                <View
                                    style={ {
                                        flex: 1,
                                        flexDirection: "row",
                                        justifyContent: 'center',
                                        alignContent: 'center'
                                    } }
                                >
                                    <View
                                        style={ {
                                            height: 120,
                                            width: "45%",


                                            marginBottom: 25,
                                            marginLeft: 10,
                                            fontSize: 18,
                                            padding: 7
                                        } }
                                    >
                                        <Text style={ {
                                            fontSize: 15, color: "#fff", justifyContent: 'center', alignContent: 'center',
                                        } }>503.2 kcal</Text>
                                        <Text style={ { fontSize: 10, color: "#fff", marginTop: Utils.moderateScale(-2) } }>Calories</Text>

                                    </View>
                                </View>
                                <ScrollView style={ { color: "#272727", width: '50%', padding: 0, margin: 0 } }>
                                </ScrollView>
                            </View>
                        </View>
                        <View style={ localStyle.innerContainer }>
                            <View style={ [GlobalStyle.card, localStyle.card] }>
                                <TouchableOpacity>

                                    <Image source={ Images.time }
                                        style={ {
                                            width: 40,
                                            height: 40,
                                            borderRadius: 40 / 2,
                                            alignItems: "center",
                                            //marginTop: -55,
                                            //marginLeft: Utils.moderateScale(15, 0.5)

                                        } }
                                    />
                                </TouchableOpacity>
                                <View
                                    style={ {
                                        flex: 1,
                                        flexDirection: "row",
                                        justifyContent: 'center',
                                        alignContent: 'center'
                                    } }
                                >
                                    <View
                                        style={ {
                                            height: 120,
                                            width: "45%",
                                            marginBottom: 25,
                                            marginLeft: 10,
                                            fontSize: 18,
                                            padding: 7
                                        } }
                                    >
                                        <Text style={ {
                                            fontSize: 15, color: "#fff", justifyContent: 'center', alignContent: 'center',
                                        } }>2h 24m</Text>
                                        <Text style={ { alignContent: 'flex-start', fontSize: 10, color: "#fff", marginTop: Utils.moderateScale(-2) } }>Time</Text>

                                    </View>
                                </View>
                            </View>
                        </View>

                    </View>

                    <View style={ {
                        flexDirection: 'row',

                    } }>
                        <View style={ localStyle.innerContainer2 }>
                            <View style={ [GlobalStyle.card, localStyle.card] }>
                                <View
                                    style={ {
                                        flex: 1,
                                        flexDirection: 'row',
                                        justifyContent: 'center',
                                        alignContent: 'center'

                                    } }
                                >
                                    <TouchableOpacity>

                                        <Image source={ Images.average_steps }
                                            style={ {
                                                width: 40,
                                                height: 40,
                                                borderRadius: 40 / 2,
                                                alignItems: "center",
                                                //marginTop: -55,
                                                //marginLeft: Utils.moderateScale(15, 0.5)

                                            } }
                                        />
                                    </TouchableOpacity>

                                    <View
                                        style={ {
                                            flex: 1,
                                            flexDirection: "row",
                                            justifyContent: 'center',
                                            alignContent: 'center'
                                        } }
                                    >
                                        <View
                                            style={ {
                                                height: 120,
                                                width: "45%",


                                                marginBottom: 25,
                                                marginLeft: 10,
                                                fontSize: 18,
                                                padding: 7
                                            } }
                                        >

                                            <Text style={ {
                                                fontSize: 15, color: "#fff", justifyContent: 'center', alignContent: 'center',
                                            } }>Average Coins</Text>
                                            <Text style={ { fontSize: 10, color: "#fff", marginTop: Utils.moderateScale(-2) } }>6000</Text><Text style={ { fontSize: 10, color: "#555555", marginTop: Utils.moderateScale(-2) } }>/per day</Text>
                                        </View>
                                    </View>
                                </View>
                            </View>
                        </View>

                        <View style={ localStyle.innerContainer2 }>
                            <View style={ [GlobalStyle.card, localStyle.card] }>
                                <TouchableOpacity>

                                    <Image source={ Images.average_coins }
                                        style={ {
                                            width: 40,
                                            height: 40,
                                            borderRadius: 40 / 2,
                                            alignItems: "center",
                                            //marginTop: -55,
                                            //marginLeft: Utils.moderateScale(15, 0.5)

                                        } }
                                    />
                                </TouchableOpacity>
                                <View
                                    style={ {
                                        flex: 1,
                                        flexDirection: "row",
                                        justifyContent: 'center',
                                        alignContent: 'center'
                                    } }
                                >
                                    <View
                                        style={ {
                                            height: 120,
                                            width: "45%",
                                            marginBottom: 25,
                                            // alignItems: 'base',
                                            fontSize: 18,
                                            padding: 5
                                        } }
                                    >
                                        <Text style={ {
                                            fontSize: 15, color: "#fff", justifyContent: 'center', alignContent: 'center',
                                        } }>Average Steps</Text>
                                        <Text style={ { fontSize: 10, color: "#fff", marginTop: Utils.moderateScale(-2) } }>6000</Text><Text style={ { fontSize: 10, color: "#555555", marginTop: Utils.moderateScale(-2) } }>/per day</Text>
                                    </View>
                                </View>
                                <ScrollView style={ { color: "#272727", width: '50%', padding: 0, margin: 0 } }>
                                </ScrollView>
                            </View>
                        </View>


                    </View>

                </ScrollView>
            </ImageBackground>
        );
    }
}

// define your styles
const localStyle = StyleSheet.create({
    MainContainer: {
        flex: 1,
        paddingTop: 20,
        alignItems: "center",
        marginTop: 50,
        justifyContent: "center"
    },
    container: {
        flex: 1,
        marginTop: 5,
        marginLeft: 10,
        alignSelf: 'stretch',
        padding: 3,
        margin: 2
    },

    input: {
        marginTop: 5,
        marginLeft: 10,
        alignSelf: 'stretch',
        padding: 3,
        margin: 2

    },
    input1: {
        marginTop: 5,
        marginLeft: 0,
        // alignSelf: 'stretch', 
        padding: 5,
        borderBottomColor: '#555555',
        margin: 5,
        marginRight: 0,
        borderBottomColor: '#555555',
        borderBottomWidth: 2
    },
    TextStyle2: {
        alignItems: 'center',
        color: '#555555',
        marginTop: 2,
        marginLeft: 10,
        alignSelf: 'stretch',
        padding: 3,
        margin: 2

    },
    buttonContainer1: {
        marginVertical: Utils.moderateVerticalScale(30),
        height: Utils.moderateVerticalScale(60),
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: Utils.moderateVerticalScale(50),
    },
    innerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignContent: 'center',
        width: 150,
        height: 150,
        padding: 0.5

    },
    innerContainer2: {
        flex: 1,
        justifyContent: 'center',
        alignContent: 'center',
        width: 150,
        height: 120,
        padding: 0.5

    },
    card: {
        margin: Utils.moderateScale(5),
        backgroundColor: '#272727',
        flex: 1,
        justifyContent: 'center',
        alignContent: 'center',

    },

});

const mapStateToProps = state => {
    return {};
};

const mapDispatchToProps = dispatch => {
    return {};
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(HomeScreen);     