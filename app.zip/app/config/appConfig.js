export const Config = {
  PageSize: 5,
  Production: false,

  WebURlLocal: "",
  ImageURLProduction: "http://13.233.145.33/",
  // APIsURLLocal: "http://192.168.1.146:3002/api/v1/",
  APIsURLLocal: "http://13.233.145.33/apiserver/api/v1/",

  WebURlProduction: "",
  APIsURLProduction: "",
};